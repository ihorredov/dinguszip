<?php
$array = [1,2,3];
$sortArrayObject = new \classes\SortArray();
$sortArrayObject->setArray($array);
var_dump($sortArrayObject->sort());