-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 08 2021 г., 18:30
-- Версия сервера: 5.7.29
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `checkboxes`
--

CREATE TABLE `checkboxes` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `checkboxes_instance`
--

CREATE TABLE `checkboxes_instance` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `checkbox_fields`
--

CREATE TABLE `checkbox_fields` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `checkbox_fields_instance`
--

CREATE TABLE `checkbox_fields_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `fields`
--

CREATE TABLE `fields` (
  `id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `instance`
--

CREATE TABLE `instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `many_files_info`
--

CREATE TABLE `many_files_info` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `file` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `many_files_info_instance`
--

CREATE TABLE `many_files_info_instance` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `file` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `many_pictures`
--

CREATE TABLE `many_pictures` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `many_pictures_instance`
--

CREATE TABLE `many_pictures_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `object`
--

CREATE TABLE `object` (
  `id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `is_assoc` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `object_fields`
--

CREATE TABLE `object_fields` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `one_file_info`
--

CREATE TABLE `one_file_info` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `file` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `one_file_info_instance`
--

CREATE TABLE `one_file_info_instance` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `file` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `one_picture`
--

CREATE TABLE `one_picture` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `one_picture_instance`
--

CREATE TABLE `one_picture_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `radiobuttons`
--

CREATE TABLE `radiobuttons` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `radiobuttons_instance`
--

CREATE TABLE `radiobuttons_instance` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `radio_fields`
--

CREATE TABLE `radio_fields` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `radio_fields_instance`
--

CREATE TABLE `radio_fields_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `text_area`
--

CREATE TABLE `text_area` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `text_area_instance`
--

CREATE TABLE `text_area_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `text_fields`
--

CREATE TABLE `text_fields` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `text_fields_instance`
--

CREATE TABLE `text_fields_instance` (
  `id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `k` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_reset_token` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `verification_token` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `checkboxes`
--
ALTER TABLE `checkboxes`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `checkboxes_instance`
--
ALTER TABLE `checkboxes_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `checkbox_fields`
--
ALTER TABLE `checkbox_fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `checkbox_fields_instance`
--
ALTER TABLE `checkbox_fields_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `instance`
--
ALTER TABLE `instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `many_files_info`
--
ALTER TABLE `many_files_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `many_files_info_instance`
--
ALTER TABLE `many_files_info_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `many_pictures`
--
ALTER TABLE `many_pictures`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `many_pictures_instance`
--
ALTER TABLE `many_pictures_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `object`
--
ALTER TABLE `object`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `k` (`k`);

--
-- Индексы таблицы `object_fields`
--
ALTER TABLE `object_fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `one_file_info`
--
ALTER TABLE `one_file_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `one_file_info_instance`
--
ALTER TABLE `one_file_info_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `one_picture`
--
ALTER TABLE `one_picture`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `one_picture_instance`
--
ALTER TABLE `one_picture_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `radiobuttons`
--
ALTER TABLE `radiobuttons`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `radiobuttons_instance`
--
ALTER TABLE `radiobuttons_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `radio_fields`
--
ALTER TABLE `radio_fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `radio_fields_instance`
--
ALTER TABLE `radio_fields_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `text_area`
--
ALTER TABLE `text_area`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `text_area_instance`
--
ALTER TABLE `text_area_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `text_fields`
--
ALTER TABLE `text_fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `text_fields_instance`
--
ALTER TABLE `text_fields_instance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `checkboxes`
--
ALTER TABLE `checkboxes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `checkboxes_instance`
--
ALTER TABLE `checkboxes_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `checkbox_fields`
--
ALTER TABLE `checkbox_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `checkbox_fields_instance`
--
ALTER TABLE `checkbox_fields_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `instance`
--
ALTER TABLE `instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `many_files_info`
--
ALTER TABLE `many_files_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `many_files_info_instance`
--
ALTER TABLE `many_files_info_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `many_pictures`
--
ALTER TABLE `many_pictures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `many_pictures_instance`
--
ALTER TABLE `many_pictures_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `object`
--
ALTER TABLE `object`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `object_fields`
--
ALTER TABLE `object_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `one_file_info`
--
ALTER TABLE `one_file_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `one_file_info_instance`
--
ALTER TABLE `one_file_info_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `one_picture`
--
ALTER TABLE `one_picture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `one_picture_instance`
--
ALTER TABLE `one_picture_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `radiobuttons`
--
ALTER TABLE `radiobuttons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `radiobuttons_instance`
--
ALTER TABLE `radiobuttons_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `radio_fields`
--
ALTER TABLE `radio_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `radio_fields_instance`
--
ALTER TABLE `radio_fields_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `text_area`
--
ALTER TABLE `text_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `text_area_instance`
--
ALTER TABLE `text_area_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `text_fields`
--
ALTER TABLE `text_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `text_fields_instance`
--
ALTER TABLE `text_fields_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
