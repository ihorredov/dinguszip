<?php
namespace backend\controllers;

use common\models\Checkboxes;
use common\models\CheckboxesInstance;
use common\models\CheckboxFields;
use common\models\CheckboxFieldsInstance;
use common\models\FieldFactory;
use common\models\Instance;
use common\models\ManyFilesInfo;
use common\models\ManyPictures;
use common\models\ManyPicturesInstance;
use common\models\Object;
use common\models\OneFileInfo;
use common\models\OnePicture;
use common\models\OnePictureInstance;
use common\models\Radiobuttons;
use common\models\RadiobuttonsInstance;
use common\models\RadioFields;
use common\models\RadioFieldsInstance;
use common\models\TextArea;
use common\models\TextAreaInstance;
use common\models\TextFields;
use common\models\TextFieldsInstance;
use common\models\UploadFileForm;
use common\models\User;
use Yii;
use yii\db\Exception;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['login', 'error'],
                        'allow' => true,
                    ],
                    [
                        'actions' => ['logout', 'index', 'create', 'create-assoc', 'createitem', 'additem', 'list', 'edit',
                            'submitobject', 'submitobjectfields', 'content', 'changebox', 'changeradio',
                            'changeobjectname', 'changename', 'changearea', 'one-file', 'many-files', 'delete-file', 'change-format',
                            'edit-structure', 'delete-old-field', 'edit-old-field', 'add-instance', 'instance-list',
                            'delete-instance', 'instance-edit', 'delete-object'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
          /*  'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],*/
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function beforeAction($action)
    {

        $this->enableCsrfValidation = false;


        return parent::beforeAction($action);
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $this->layout = false;
        $objects = $this->getObjects();
        return $this->render('index', ['objects' => $objects]);
    }

    public function actionCreate()
    {
        $this->layout = false;
        $create = true;
        $objects = $this->getObjects();
        return $this->render('create', ['create' => $create, 'objects' => $objects, 'is_assoc' => 0]);
    }

    public function actionCreateAssoc()
    {
        $this->layout = false;
        $create = true;
        $objects = $this->getObjects();
        return $this->render('create', ['create' => $create, 'objects' => $objects, 'is_assoc' => 1]);
    }

    public function actionEdit($id)
    {
        $this->layout = false;
        $create = false;
        $object = Object::find()->where(['id' => $id])->one();
        $objects = $this->getObjects();
        if(!$object) {
            throw new NotFoundHttpException();
        }
        return $this->render('edit', ['create' => $create, 'object' => $object, 'objects' => $objects]);
    }

    public function actionCreateitem()
    {
        $this->layout = false;
        return $this->render('createItem');
    }

    public function actionAdditem()
    {
        $this->layout = false;
        return $this->render('addItem');
    }

    public function actionList()
    {
        $this->layout = false;
        return $this->render('listElements');
    }

    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $this->layout = false;

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            $model->password = '';

            return $this->render('login2', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionSubmitobject()
    {
        if($_POST['create'] == 'true') {
            $object = new Object();
            $object->is_assoc = $_POST['is_assoc'];
        } else {
            $object = Object::find()->where(['id' =>$_POST['id']])->one();
        }

        $object->name = $_POST['name'];
        $object->k = $_POST['k'];
        $object->description = $_POST['desc'];
        $object->user_id = Yii::$app->user->id;
        if($object->save()) {
            $response['id'] = $object->getPrimaryKey();
            return json_encode($response);
        }


    }

    private function getObjects()
    {
        return Object::find()->where(['user_id' => Yii::$app->user->id])->all();
    }

    public function actionSubmitobjectfields()
    {
        $objectId = $_POST['object_id'];

        if(isset($_POST['text']) && $_POST['text']) {
            foreach ($_POST['text'] as $text) {
                $textObj = new TextFields();
                $textObj->object_id = $objectId;
                $textObj->k = $text['key'];
                $textObj->text = $text['value'];
                $textObj->label = $text['value'];
                $textObj->save();
            }

        }

        if(isset($_POST['textarea']) && $_POST['textarea']) {
            foreach ($_POST['textarea'] as $textarea) {
                $textareaObj = new TextArea();
                $textareaObj->object_id = $objectId;
                $textareaObj->text = $textarea['value'];
                $textareaObj->k = $textarea['key'];
                $textareaObj->label = $textarea['key'];
                $textareaObj->save();
            }
        }


        if(isset($_POST['check']) && $_POST['check']) {
            foreach($_POST['check'] as $check) {
                $checkObj = new CheckboxFields();
                $checkObj->object_id = $objectId;
                $checkObj->k = $check['key'];
                $checkObj->name = $check['val'];
                if($checkObj->save()) {
                    if (isset($check['fields']) && $check['fields']) {
                        foreach ($check['fields'] as $field) {
                            $checkbox = new Checkboxes();
                            $checkbox->field_id = $checkObj->getPrimaryKey();
                            $checkbox->k = $field['key'];
                            $checkbox->name = $field['val'];
                            $checkbox->save();
                        }
                    }
                } else {
                    var_dump($checkObj->getErrors());
                }
            }
        }

        if(isset($_POST['radio']) && $_POST['radio']) {
            foreach($_POST['radio'] as $radio) {
                $radioObj = new RadioFields();
                $radioObj->object_id = $objectId;
                $radioObj->k = $radio['key'];
                $radioObj->name = $radio['val'];
                if($radioObj->save()) {
                    if (isset($radio['fields']) && $radio['fields']) {
                        foreach ($radio['fields'] as $field) {
                            $radioF = new Radiobuttons();
                            $radioF->field_id = $radioObj->getPrimaryKey();
                            $radioF->k = $field['key'];
                            $radioF->name = $field['val'];
                            $radioF->save();
                        }
                    }
                } else {
                    var_dump($radioObj->getErrors());
                }
            }
        }

        if(isset($_POST['one_img']) && $_POST['one_img']) {
            foreach ($_POST['one_img'] as $one_img) {
                $onePicObj = new OnePicture();
                $onePicObj->object_id = $objectId;
                $onePicObj->k = $one_img['key'];
                $onePicObj->name = $one_img['val'];
                $onePicObj->height = $one_img['height'];
                $onePicObj->width = $one_img['width'];
                if(!$onePicObj->save()) {
                    var_dump($onePicObj->getErrors());
                }
            }
        }

        if(isset($_POST['many_img']) && $_POST['many_img']) {
            foreach ($_POST['many_img'] as $many_img) {
                $manyPicObj = new ManyPictures();
                $manyPicObj->object_id = $objectId;
                $manyPicObj->k = $many_img['key'];
                $manyPicObj->name = $many_img['val'];
                $manyPicObj->height = $many_img['height'];
                $manyPicObj->width = $many_img['width'];
                if(!$manyPicObj->save()) {
                    var_dump($manyPicObj->getErrors());
                }
            }
        }

        die(json_encode($_POST));
    }

    public function actionContent($id)
    {
        $this->layout = false;
        $object = Object::find()->where(['id' => $id])->one();
        $textField = TextFields::find()->where(['object_id' => $id])->all();
        $textArea = TextArea::find()->where(['object_id' => $id])->all();
        $checkbox = CheckboxFields::find()->where(['object_id' => $id])->all();
        $objects = $this->getObjects();

        if($checkbox) {
            foreach ($checkbox as $key => $value) {
                $boxes = Checkboxes::find()->where(['field_id' => $value->id])->all();
                $checkbox[$key]->boxes = $boxes;
            }
        }

        $radio = RadioFields::find()->where(['object_id' => $id])->all();
        if($radio) {
            foreach ($radio as $key => $value) {
                $buttons = Radiobuttons::find()->where(['field_id' => $value->id])->all();
                $radio[$key]->buttons = $buttons;
            }
        }

        $oneImg = OnePicture::find()
            ->select('one_picture.*, one_file_info.file as file, one_file_info.id as img_id')
            ->leftJoin('one_file_info', 'one_file_info.field_id = one_picture.id')
            ->where(['object_id' => $id])->all();
        $oneFileModel = new UploadFileForm();
        $manyImg = ManyPictures::find()->where(['object_id' => $id])->all();


        return $this->render('addItem' , [
            'object' => $object,
            'objects' => $objects,
            'textField' => $textField,
            'textArea' => $textArea,
            'checkbox' => $checkbox,
            'radio' => $radio,
            'oneImg' => $oneImg,
            'oneFileModel' => $oneFileModel,
            'manyImg' => $manyImg,
        ]);
    }

    public function actionChangebox()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $val = 0;
            if($_POST['val'] == 'true') {
                $val = 1;
            }
            $checkbox = Checkboxes::find()->where(['id' => $_POST['id']])->one();
            if($checkbox) {
                $checkbox->enabled = $val;
                $checkbox->save();
            }
        }
    }

    public function actionChangeradio()
    {
        if(isset($_POST['id']) && isset($_POST['parent'])) {
            $radio = Radiobuttons::find()->where(['field_id' => $_POST['parent']])->all();
            if($radio) {
                foreach($radio as $r) {
                    if($r->id == $_POST['id']) {
                        $r->enabled = 1;
                    } else {
                        $r->enabled = 0;
                    }

                    $r->save();
                }
            }
        }
    }

    public function actionChangeobjectname()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $object = Object::find()->where(['id' => $_POST['id']])->one();
            if($object) {
                $object->name = $_POST['val'];
                $object->save();
            }
        }
    }

    public function actionChangename()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $text = TextFields::find()->where(['id' => $_POST['id']])->one();
            if($text) {
                $text->text = $_POST['val'];
                $text->save();
            }
        }
    }

    public function actionChangearea()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $text = TextArea::find()->where(['id' => $_POST['id']])->one();
            if($text) {
                $text->text = $_POST['val'];
                $text->save();
            }
        }
    }

    public function actionOneFile()
    {
        $model = new UploadFileForm();
        $url = 'http://'.$_SERVER['SERVER_NAME'].'/admin?r=site/content&id='.$_POST['UploadFileForm']['object_id'];

        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ($model->upload($_POST['UploadFileForm']['id'])) {
                Yii::$app->session->setFlash('success', 'Изображение загружено');
                header('Location: '.$url);
            }
        }
        header('Location: '.$url);
        die();
    }

    public function actionManyFiles()
    {
        $url = 'http://'.$_SERVER['SERVER_NAME'].'/admin?r=site/content&id='.$_POST['UploadFileForm']['object_id'];
        $model = new UploadFileForm();

        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ($model->upload($_POST['UploadFileForm']['id'], 'many')) {
                Yii::$app->session->setFlash('success', 'Изображение загружено');
                header('Location: '.$url);
            }
        }
        header('Location: '.$url);
        die();
    }

    public function actionDeleteFile()
    {
        if(isset($_POST['id']) && isset($_POST['type'])) {
            $class = $_POST['type']=='many'?new ManyFilesInfo():new OneFileInfo();
            $model = $class::find()->where(['id' => $_POST['id']])->one();
            if($model) {
                unlink($_SERVER['DOCUMENT_ROOT'].'/backend/web/uploads/'.$model->file);
                $model->delete();
            }
        }
    }

    public function actionChangeFormat()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $object = Object::find()->where(['id' => $_POST['id']])->one();
            $object->format = $_POST['val'];
            $object->save();
        }
    }

    public function actionEditStructure($id)
    {
        $this->layout = false;
        $object = Object::find()->where(['id' => $id])->one();
        if(!$object) {
            throw new NotFoundHttpException();
        }

        $textFields = TextFields::find()->where(['object_id' => $id])->all();
        $textArea = TextArea::find()->where(['object_id' => $id])->all();
        $radioField = RadioFields::find()->where(['object_id' => $id])->all();
        $checkField = CheckboxFields::find()->where(['object_id' => $id])->all();
        $onePicture = OnePicture::find()->where(['object_id' => $id])->all();
        $manyPictures = ManyPictures::find()->where(['object_id' => $id])->all();
        $objects = $this->getObjects();

        return $this->render('editStructure', [
            'object' => $object,
            'textFields' => $textFields,
            'textArea' => $textArea,
            'radioField' => $radioField,
            'checkField' => $checkField,
            'onePicture' => $onePicture,
            'manyPictures' => $manyPictures,
            'objects' => $objects
        ]);
    }

    public function actionDeleteOldField()
    {
        if(isset($_POST['type']) && $_POST['id']) {
            $fieldClass = new FieldFactory();
            $object = $fieldClass->create($_POST['type'], $_POST['id']);
            if($object) {
                $object->deleteFieldById();
            }
        }

    }

    public function actionEditOldField()
    {
        if(isset($_POST['type']) && isset($_POST['id']) && isset($_POST['field']) && isset($_POST['value'])) {
            $fieldClass = new FieldFactory();
            $object = $fieldClass->create($_POST['type'], $_POST['id']);
            if($object) {
                $object->editFieldById($_POST['field'], $_POST['value']);
            }
        }
    }

    public function actionAddInstance($id)
    {
        $object = Object::find()->where(['id' => $id])->one();

        $instance = new Instance();
        $instance->object_id = $id;
        $instance->name = 'Экземпляр объекта '.$id;
        if(!$instance->save()) {
            throw new NotFoundHttpException();
        }

        $instanceId = $instance->getPrimaryKey();

        $textField = TextFields::find()->where(['object_id' => $id])->all();
        if($textField) {
            foreach ($textField as $tf) {
                $textFieldInstance = new TextFieldsInstance();
                $textFieldInstance->object_id = $tf->object_id;
                $textFieldInstance->instance_id = $instanceId;
                $textFieldInstance->k = $tf->k;
                $textFieldInstance->text = $tf->text;
                $textFieldInstance->label = $tf->text;
                $textFieldInstance->save();
            }
        }

        $textArea = TextArea::find()->where(['object_id' => $id])->all();

        if($textArea) {
            foreach ($textArea as $ta) {
                $textAreaInstance = new TextAreaInstance();
                $textAreaInstance->object_id = $id;
                $textAreaInstance->instance_id = $instanceId;
                $textAreaInstance->k = $ta->k;
                $textAreaInstance->text = $ta->text;
                $textAreaInstance->label = $ta->text;
                if(!$textAreaInstance->save()) {
                    var_dump($textAreaInstance->getErrors());
                }
            }
        }

        $checkbox = CheckboxFields::find()->where(['object_id' => $id])->all();
        $objects = $this->getObjects();

        if($checkbox) {
            foreach ($checkbox as $key => $value) {

                $checkboxInstance = new CheckboxFieldsInstance();
                $checkboxInstance->object_id = $id;
                $checkboxInstance->instance_id = $instanceId;
                $checkboxInstance->k = $value->k;
                $checkboxInstance->name = $value->name;
                if(!$checkboxInstance->save()) {
                    throw new NotFoundHttpException();
                }

                $boxes = Checkboxes::find()->where(['field_id' => $value->id])->all();

                if ($boxes) {
                    foreach ($boxes as $b) {
                        $boxInstance = new CheckboxesInstance();
                        $boxInstance->instance_id = $instanceId;
                        $boxInstance->field_id = $checkboxInstance->getPrimaryKey();
                        $boxInstance->k = $b->k;
                        $boxInstance->name = $b->name;
                        $boxInstance->enabled = $b->enabled;
                        $boxInstance->save();
                        }
                }
            }
        }

        $radio = RadioFields::find()->where(['object_id' => $id])->all();

        if($radio) {
            foreach ($radio as $key => $value) {

                $radioFieldInstance = new RadioFieldsInstance();
                $radioFieldInstance->object_id = $id;
                $radioFieldInstance->instance_id = $instanceId;
                $radioFieldInstance->k = $value->k;
                $radioFieldInstance->name = $value->name;
                if(!$radioFieldInstance->save()) {
                    throw new NotFoundHttpException();
                }

                $rboxes = Radiobuttons::find()->where(['field_id' => $value->id])->all();

                if ($rboxes) {
                    foreach ($rboxes as $b) {
                        $boxInstance = new RadiobuttonsInstance();
                        $boxInstance->field_id = $radioFieldInstance->getPrimaryKey();
                        $boxInstance->k = $b->k;
                        $boxInstance->name = $b->name;
                        $boxInstance->enabled = $b->enabled;
                        $boxInstance->save();
                    }
                }
            }
        }

        $oneImg = OnePicture::find()->where(['object_id' => $id])->all();
        if($oneImg) {
            foreach ($oneImg as $img) {
                $oneImgInstance = new OnePictureInstance();
                $oneImgInstance->object_id = $id;
                $oneImgInstance->instance_id = $instanceId;
                $oneImgInstance->k = $img->k;
                $oneImgInstance->name = $img->name;
                $oneImgInstance->height = $img->height;
                $oneImgInstance->width = $img->width;
                $oneImgInstance->save();
            }
        }


       // $oneFileModel = new UploadFileForm();

        $manyImg = ManyPictures::find()->where(['object_id' => $id])->all();
        if($manyImg) {
            foreach ($manyImg as $ming) {
                $manyImgInstance = new ManyPicturesInstance();
                $manyImgInstance->object_id = $id;
                $manyImgInstance->instance_id = $instanceId;
                $manyImgInstance->k = $ming->k;
                $manyImgInstance->name = $ming->name;
                $manyImgInstance->height = $ming->height;
                $manyImgInstance->width = $ming->width;
                $manyImgInstance->save();
            }
        }




        if(Yii::$app->request->referrer){
            return $this->redirect(Yii::$app->request->referrer);
        }else{
            return $this->goHome();
        }
        die();
    }

    public function actionInstanceList($id)
    {
        $this->layout = false;
        $instance = Instance::find()->where(['object_id' => $id])->all();
        $objects = $this->getObjects();
        $objectt = Object::find()->where(['id' => $id])->one();

        return $this->render('listElements', ['instances' => $instance, 'objects' => $objects, 'objectt' => $objectt]);
    }


    public function actionInstanceEdit($id)
    {
        $this->layout = false;
        $instance = Instance::find()->where(['id' => $id])->one();
        $textField = TextFieldsInstance::find()->where(['instance_id' => $id])->all();
        $textArea = TextAreaInstance::find()->where(['instance_id' => $id])->all();
        $checkbox = CheckboxFieldsInstance::find()->where(['instance_id' => $id])->all();
        $objects = $this->getObjects();

        if($checkbox) {
            foreach ($checkbox as $key => $value) {
                $boxes = CheckboxesInstance::find()->where(['field_id' => $value->id])->all();
                $checkbox[$key]->boxes = $boxes;
            }
        }

        $radio = RadioFieldsInstance::find()->where(['instance_id' => $id])->all();
        if($radio) {
            foreach ($radio as $key => $value) {
                $buttons = RadiobuttonsInstance::find()->where(['field_id' => $value->id])->all();
                $radio[$key]->buttons = $buttons;
            }
        }

        $oneImg = OnePictureInstance::find()
            ->select('one_picture_instance.*, one_file_info_instance.file as file, one_file_info_instance.id as img_id')
            ->leftJoin('one_file_info_instance', 'one_file_info_instance.field_id = one_picture_instance.id')
            ->where(['instance_id' => $id])->all();
        $oneFileModel = new UploadFileForm();
        $manyImg = ManyPicturesInstance::find()->where(['instance_id' => $id])->all();


        return $this->render('editInstance' , [
            'instance' => $instance,
            'objects' => $objects,
            'textField' => $textField,
            'textArea' => $textArea,
            'checkbox' => $checkbox,
            'radio' => $radio,
            'oneImg' => $oneImg,
            'oneFileModel' => $oneFileModel,
            'manyImg' => $manyImg,
        ]);
    }

    public function actionDeleteObject($id) {
        $object = Object::find()->where(['id' => $id])->one();
        if($object) {
            if($object->is_assoc == 1) {
                $instance = Instance::find()->where(['object_id' => $id])->all();
                if($instance) {
                    foreach ($instance as $i) {
                        $i->delete();
                    }
                }
            }
            $object->delete();
        }

        header('Location: /admin');
        die();
    }

    public function actionDeleteInstance($id)
    {
        $ins = Instance::find()->where(['id' => $id])->one();
        if($ins) {
            $ins->delete();
        }

        return $this->redirect(Yii::$app->request->referrer);
        die();
    }
}
