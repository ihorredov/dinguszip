<?php


namespace backend\controllers;


use common\models\Checkboxes;
use common\models\CheckboxesInstance;
use common\models\Instance;
use common\models\ManyFilesInfo;
use common\models\ManyFilesInfoInstance;
use common\models\Object;
use common\models\OneFileInfo;
use common\models\OneFileInfoInstance;
use common\models\Radiobuttons;
use common\models\RadiobuttonsInstance;
use common\models\TextArea;
use common\models\TextAreaInstance;
use common\models\TextFields;
use common\models\TextFieldsInstance;
use common\models\UploadFileForm;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\UploadedFile;

class InstanceController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['changebox', 'changeradio', 'changeobjectname', 'changename', 'changearea',
                            'one-file', 'many-files', 'delete-file', 'change-format'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function beforeAction($action)
    {

        $this->enableCsrfValidation = false;


        return parent::beforeAction($action);
    }

    public function actionChangebox()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $val = 0;
            if($_POST['val'] == 'true') {
                $val = 1;
            }
            $checkbox = CheckboxesInstance::find()->where(['id' => $_POST['id']])->one();
            if($checkbox) {
                $checkbox->enabled = $val;
                $checkbox->save();
            }
        }
    }

    public function actionChangeradio()
    {
        if(isset($_POST['id']) && isset($_POST['parent'])) {
            $radio = RadiobuttonsInstance::find()->where(['field_id' => $_POST['parent']])->all();
            if($radio) {
                foreach($radio as $r) {
                    if($r->id == $_POST['id']) {
                        $r->enabled = 1;
                    } else {
                        $r->enabled = 0;
                    }

                    $r->save();
                }
            }
        }
    }

    public function actionChangeobjectname()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $object = Instance::find()->where(['id' => $_POST['id']])->one();
            if($object) {
                $object->name = $_POST['val'];
                $object->save();
            }
        }
    }

    public function actionChangename()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $text = TextFieldsInstance::find()->where(['id' => $_POST['id']])->one();
            if($text) {
                $text->text = $_POST['val'];
                $text->save();
            }
        }
    }

    public function actionChangearea()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $text = TextAreaInstance::find()->where(['id' => $_POST['id']])->one();
            if($text) {
                $text->text = $_POST['val'];
                $text->save();
            }
        }
    }

    public function actionOneFile()
    {
        $model = new UploadFileForm();
        $url = 'http://'.$_SERVER['SERVER_NAME'].'/admin?r=site/instance-edit&id='.$_POST['UploadFileForm']['instance_id'];
        if (\Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ($model->uploadInstance($_POST['UploadFileForm']['id'])) {
                \Yii::$app->session->setFlash('success', 'Изображение загружено');
                header('Location: '.$url);
            }
        }
        header('Location: '.$url);
        die();
    }

    public function actionManyFiles()
    {
        $url = 'http://'.$_SERVER['SERVER_NAME'].'/admin?r=site/instance-edit&id='.$_POST['UploadFileForm']['instance'];
        $model = new UploadFileForm();

        if (\Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            if ($model->uploadInstance($_POST['UploadFileForm']['id'], 'many')) {
                \Yii::$app->session->setFlash('success', 'Изображение загружено');
                header('Location: '.$url);
            }
        }
        header('Location: '.$url);
        die();
    }

    public function actionDeleteFile()
    {
        if(isset($_POST['id']) && isset($_POST['type'])) {
            $class = $_POST['type']=='many'?new ManyFilesInfoInstance():new OneFileInfoInstance();
            $model = $class::find()->where(['id' => $_POST['id']])->one();
            if($model) {
                unlink($_SERVER['DOCUMENT_ROOT'].'/backend/web/uploads/'.$model->file);
                $model->delete();
            }
        }
    }

    public function actionChangeFormat()
    {
        if(isset($_POST['id']) && isset($_POST['val'])) {
            $object = Instance::find()->where(['id' => $_POST['id']])->one();
            $object->format = $_POST['val'];
            $object->save();
        }
    }

}