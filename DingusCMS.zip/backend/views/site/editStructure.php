<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dignus CMS | Project Add</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <div class="object_id" data-id = '<?php echo $_GET['id']?>'></div>


    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="/admin" class="brand-link">
           
            <span class="brand-text font-weight-light">Dignus CMS</span>
        </a>
        <div class="mt-3 sidebar">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if($objects):?>
                    <?php foreach ($objects as $obj): ?>
                        <?php if($obj->existFields()):?>
                            <?php $url = 'edit-structure';?>
                            <?php $exist = true; ?>
                        <?php else: ?>
                            <?php $url = 'edit';?>
                            <?php $exist = false; ?>
                        <?php endif;?>
                        <li class="nav-item">
                            <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                                <i class="nav-icon fas fa-file"></i>
                                <p><?php echo $obj->name?></p>
                            </a>
                            <ul class="nav nav-treeview" style="display: none;">
                                <?php if($obj->is_assoc == 0):?>
                                    <li class="nav-item">
                                        <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                                            <i class="fas fa-pen nav-icon"></i>
                                            <p>Структура</p>
                                        </a>
                                    </li>
                                <?php else:?>

                                    <?php if($exist):?>
                                        <li class="nav-item">
                                            <a href="/admin?r=site/instance-list&id=<?php echo $obj->id?>" class="nav-link">
                                                <i class="fas fa-pen nav-icon"></i>
                                                <p>Экземпляры</p>
                                            </a>
                                        </li>
                                    <?php endif;?>
                                <?php endif;?>
                                <?php if($exist && $obj->is_assoc == 0):?>
                                    <li class="nav-item">
                                        <a href="/admin?r=site/content&id=<?php echo $obj->id?>" class="nav-link">
                                            <i class="fas fa-pen nav-icon"></i>
                                            <p>Наполнение</p>
                                        </a>
                                    </li>
                                <?php endif;?>

                                <li class="nav-item">
                                    <a target="_blank" href="/web/index.php?r=site/object&id=<?php echo $obj->id?>" class="nav-link">
                                        <i class="fas fa-pen nav-icon"></i>
                                        <p>Просмотреть вывод в массиве</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a target="_blank" href="/web/index.php?r=site/object-json&id=<?php echo $obj->id?>" class="nav-link">
                                        <i class="fas fa-pen nav-icon"></i>
                                        <p>Просмотреть вывод в json</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a onclick="return confirm('Удалить объект?')" href="/admin?r=site/delete-object&id=<?php echo $obj->id?>" class="nav-link">
                                        <i class="fas fa-trash nav-icon"></i>
                                        <p style="color:red">Удалить объект</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php endforeach;?>
                <?php endif;?>
            </ul>

        </div>

    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Создайте свой первый экземпляр объекта</h1>
                    </div>

                </div>
            </div><!-- /.container-fluid -->
        </section>


        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Структура объекта</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div id="object_id" data-id = '<?php echo isset($object->id)?$object->id:0?>'></div>
                        <div class="card-body" id="mainStructure">
                            <div class="form-group">
                                <label for="inputName">Название</label>
                                <input type="text" id="inputName" class="form-control" value="<?php echo $object->name?>">
                            </div>
                            <div class="form-group">
                                <label for="inputName">Ключ (только латиницей)</label>
                                <input type="text" id="inputKey" class="form-control" value="<?php echo $object->k?>">
                            </div>
                            <div class="form-group">
                                <label for="inputDescription">Описание для администратора (инструкция)</label>
                                <textarea id="inputDescription" class="form-control" rows="4"><?php echo $object->description?></textarea>
                            </div>


                            <?php if($textFields):?>
                                <?php foreach($textFields as $textField):?>
                                    <div class="form-group row border-top pt-3 add-text-old">

                                        <label for="oldField_<?php echo $textField->id?>>" class="col-sm-3 col-form-label col-form-label">Текст</label>
                                        <div class="col-sm-2">
                                            <input type="input" value="<?php echo $textField->k?>" class="form-control form-control add-text-key edit-old-field" data-field = 'k' data-type="text" data-id="<?php echo $textField->id?>" id="oldFieldKey<?php echo $textField->id?>" placeholder="Ключ">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="input" value="<?php echo $textField->text?>" class="form-control form-control add-text-value edit-old-field" data-field = 'text' data-type="text" data-id="<?php echo $textField->id?>" id="oldField_<?php echo $textField->id?>" placeholder="Введите название для поля">
                                        </div>
                                        <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-id="<?php echo $textField->id?>" data-type="text">×</button></div>
                                    </div>
                                <?php endforeach;?>
                            <?php endif;?>

                            <?php if($textArea):?>
                                <?php foreach ($textArea as $area):?>
                                    <div class="form-group row border-top pt-3 txt-area-old">

                                        <label for="oldField_<?php echo $area->id?>>" class="col-sm-3 col-form-label col-form-label">Текстовое поле</label>
                                        <div class="col-sm-2">
                                            <input type="input" class="form-control form-control add-textarea-key edit-old-field" data-type="textarea" data-field = 'k' data-id="<?php echo $area->id?>" value="<?php echo $area->k?>" id="newFieldKey${newFieldId}" placeholder="Ключ">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="input" value="<?php echo $area->text?>" data-field = 'text' data-type="textarea" data-id="<?php echo $area->id?>" class="form-control form-control add-textarea-old edit-old-field" id="oldField_<?php echo $area->id?>" placeholder="Введите название для текстового поля">
                                        </div>
                                        <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-type="textarea" data-id="<?php echo $area->id?>">×</button></div>
                                    </div>
                                <?php endforeach;?>
                            <?php endif;?>

                            <?php if($radioField):?>
                                <?php foreach ($radioField as $radio):?>
                                    <div class="form-group row border-top pt-3 old-add-radio f_trigger">

                                        <label for="oldField_<?php echo $radio->id?>>" class="col-sm-3 col-form-label col-form-label">Поле с радиокнопками</label>
                                        <div class="col-sm-2">
                                            <input type="input" value="<?php echo $radio->k?>" class="form-control form-control old-radio-key edit-old-field" id="oldFieldKey<?php echo $radio->id?>"  data-field = 'k' data-type="radio" data-id="<?php echo $radio->id?>" placeholder="Ключ">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="input" value="<?php echo $radio->name?>" class="form-control form-control old-radio-val edit-old-field" id="oldField_<?php echo $radio->id?>"  data-field = 'name' data-type="radio" data-id="<?php echo $radio->id?>" placeholder="Введите название для поля с радиокнопками или чекбоксами">
                                        </div>
                                        <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-type="radio" data-id = <?php echo $radio->id?>>×</button></div>
                                        <div class="col-6">
                                            <div class="alert alert-info alert-dismissible">
                                                Поле с ключами (только латинские буквы и цифры)
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="alert alert-info alert-dismissible">
                                                Поле с именами  (то, что будет написано в лейбле)
                                            </div>
                                        </div>

                                        <div class="keysAndNames row">
                                            <?php if($radioB = \common\models\Radiobuttons::find()->where(['field_id' => $radio->id])->all()):?>
                                                <?php foreach($radioB as $b):?>
                                                    <div class = 'old-radio-area row col-12 pr-0'>
                                                        <div class="col-6 mb-2">
                                                            <input value="<?php echo $b->k?>" type="text" class="form-control radio-field-key edit-old-field"  data-field = 'k' data-type="radio-b" data-id="<?php echo $b->id?>" placeholder="Ключ">
                                                        </div>
                                                        <div class="col-6 mb-2">
                                                            <input value="<?php echo $b->name?>" type="text" class="form-control radio-field-val edit-old-field"  data-field = 'name' data-type="radio-b" data-id="<?php echo $b->id?>" placeholder="Имя">
                                                        </div>
                                                    </div>
                                                <?php endforeach;?>
                                            <?php endif;?>

                                            <div class="col-12 mb-2">
                                                <button class="btn btn-success float-right addSeccondFields">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach;?>
                            <?php endif;?>

                            <?php if($checkField):?>
                                <?php foreach ($checkField as $check):?>
                                    <div class="form-group row border-top pt-3 old-add-check f_trigger">

                                        <label for="oldField_<?php echo $check->id?>>" class="col-sm-3 col-form-label col-form-label">Поле с чекбоксами</label>
                                        <div class="col-sm-2">
                                            <input type="input" value="<?php echo $check->k?>" class="form-control form-control old-check-key edit-old-field"  data-field = 'k' data-type="check" data-id="<?php echo $check->id?>" id="oldFieldKey<?php echo $check->id?>>" placeholder="Ключ">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="input" value="<?php echo $check->name?>" class="form-control form-control old-check-val edit-old-field"  data-field = 'name' data-type="check" data-id="<?php echo $check->id?>" id="oldField_<?php echo $check->id?>" placeholder="Введите название для поля с радиокнопками или чекбоксами">
                                        </div>
                                        <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-id="<?php echo $check->id?>" data-type="check">×</button></div>
                                        <div class="col-6">
                                            <div class="alert alert-info alert-dismissible">
                                                Поле с ключами (только латинские буквы и цифры)
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="alert alert-info alert-dismissible">
                                                Поле с именами  (то, что будет написано в лейбле)
                                            </div>
                                        </div>

                                        <div class="keysAndNames row">
                                            <?php if($checkB = \common\models\Checkboxes::find()->where(['field_id' => $check->id])->all()):?>
                                                <?php foreach($checkB as $b):?>
                                                    <div class = 'old-check-area row col-12 pr-0'>
                                                        <div class="col-6 mb-2">
                                                            <input value="<?php echo $b->k?>"   data-field = 'k' data-type="check-b" data-id="<?php echo $b->id?>" type="text" class="form-control check-field-key edit-old-field" placeholder="Ключ">
                                                        </div>
                                                        <div class="col-6 mb-2">
                                                            <input value="<?php echo $b->name?>" type="text"   data-field = 'name' data-type="check-b" data-id="<?php echo $b->id?>" class="form-control check-field-val edit-old-field" placeholder="Имя">
                                                        </div>
                                                    </div>
                                                <?php endforeach;?>
                                            <?php endif;?>

                                            <div class="col-12 mb-2">
                                                <button class="btn btn-success float-right addSeccondFields">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach;?>
                            <?php endif;?>

                            <?php if($onePicture):?>
                                <?php foreach($onePicture as $pic):?>
                            <div class="form-group row border-top pt-3 old-add-one-img">

                                <label for="oldField_<?php echo $pic->id?>" class="col-sm-3 col-form-label col-form-label">Одно изображение</label>
                                <div class="col-sm-2">
                                    <input type="input" value="<?php echo $pic->k?>"   data-field = 'k' data-type="one-pic" data-id="<?php echo $pic->id?>" class="form-control form-control old-one-img-key edit-old-field" id="oldFieldKey<?php echo $pic->id?>>" placeholder="Ключ">
                                </div>
                                <div class="col-sm-6">
                                    <input type="input" value="<?php echo $pic->name?>" class="form-control form-control old-one-img-val edit-old-field"   data-field = 'name' data-type="one-pic" data-id="<?php echo $pic->id?>" id="oldField_<?php echo $pic->id?>" placeholder="Введите название для изображения">
                                </div>
                                <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-id = '<?php echo $pic->id?>' data-type="one-img">×</button></div>


                              <!--  <div class="col-12">
                                    <div class="alert alert-info alert-dismissible">
                                        Поля ниже преднозначены для обрезки изображений. Если не указывать, изображение будет загружено целиком.
                                    </div>
                                </div> -->
                                <div class="row">
                                    <div class="col-6 mb-2">
                                        <input type="hidden" value="<?php echo $pic->width?>"   data-field = 'width' data-type="one-pic" data-id="<?php echo $pic->id?>" class="form-control old-one-img-width edit-old-field" placeholder="Ширина в пикселях">
                                    </div>
                                    <div class="col-6 mb-2">
                                        <input type="hidden" value="<?php echo $pic->height?>"   data-field = 'height' data-type="one-pic" data-id="<?php echo $pic->id?>" class="form-control old-one-img-height edit-old-field" placeholder="Высота в пикселях">
                                    </div>
                                </div>
                            </div>
                                <?php endforeach;?>
                            <?php endif;?>

                            <?php if($manyPictures):?>
                                <?php foreach($manyPictures as $mpic):?>
                                <div class="form-group row border-top pt-3 old-add-many-img">

                                    <label for="oldField_<?php echo $mpic->id?>>" class="col-sm-3 col-form-label col-form-label">Группа изображений</label>
                                    <div class="col-sm-2">
                                        <input type="input" value="<?php echo $mpic->k?>"   data-field = 'k' data-type="many-pic" data-id="<?php echo $mpic->id?>" class="form-control form-control old-many-img-key edit-old-field" id="oldFieldKey<?php echo $mpic->id?>" placeholder="Ключ">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="input" value="<?php echo $mpic->name?>"   data-field = 'name' data-type="many-pic" data-id="<?php echo $mpic->id?>" class="form-control form-control old-many-img-val edit-old-field" id="oldField_<?php echo $mpic->id?>" placeholder="Введите название для изображения">
                                    </div>
                                    <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields delete-old-field" data-id = '<?php echo $mpic->id?>' data-type="many-pic">×</button></div>


                                    <!--<div class="col-12">
                                        <div class="alert alert-info alert-dismissible">
                                            Поля ниже преднозначены для обрезки изображений. Если не указывать, изображение будет загружено целиком.
                                        </div>
                                    </div> -->
                                    <div class="row">
                                        <div class="col-6 mb-2">
                                            <input type="hidden" value="<?php echo $mpic->width?>"   data-field = 'width' data-type="many-pic" data-id="<?php echo $mpic->id?>" class="form-control old-many-img-width edit-old-field" placeholder="Ширина в пикселях">
                                        </div>
                                        <div class="col-6 mb-2">
                                            <input type="hidden" value="<?php echo $mpic->height?>"   data-field = 'height' data-type="many-pic" data-id="<?php echo $mpic->id?>" class="form-control old-many-img-height edit-old-field" placeholder="Высота в пикселях">
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach;?>
                            <?php endif;?>




                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <?php if(!$create): ?>
                    <div class="col-md-6">
                        <div class="card card-secondary">
                            <div class="card-header">
                                <h3 class="card-title">Поля для заполнения объекта</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body" id="cardAdd">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addText" value="1" name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addText">Текст</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addTextarea" value="2" name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addTextarea">Текстовое поле</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addCheckboxes" value="3" name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addCheckboxes">Поле с чекбоксами</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addRadios" value="4"  name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addRadios">Поле с радиокнопками</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addImg" value="5" name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addImg">Изображение</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="addImgGroup" value="6" name="radioAdd" class="custom-control-input">
                                    <label class="custom-control-label" for="addImgGroup">Группа изображений</label>
                                </div>

                                <button class="btn btn-success float-right" id="structureAdd">Добавить в структуру</button>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                <?php endif;?>
            </div>
            <div class="row">
                <div class="col-12">
                    <input type="submit" value="Создать экземпляр объекта" class="btn btn-success float-right submit-object <?php echo $create?'create':''?>">
                </div>
            </div>

        </section>
        <!-- /.content -->

    </div>
    <!-- /.content-wrapper -->



    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/admin/dist/js/demo.js"></script>
</body>
</html>

<script>
    $(document).ready(function(){

        //событие добавления сущностей
        let newFieldId = 0;


        $('#structureAdd').on('click', function(){

            let radioName = $('#cardAdd input[name="radioAdd"]:checked').attr('id');
            let createInputField = '';


            if(radioName == "addText") {

                createInputField = `<div class="form-group row border-top pt-3 add-text">

              <label for="newField_${newFieldId}" class="col-sm-3 col-form-label col-form-label">Текст</label>
              <div class="col-sm-2">
                <input type="input" class="form-control form-control add-text-key" id="newFieldKey${newFieldId}" placeholder="Ключ">
              </div>
              <div class="col-sm-6">
                <input type="input" class="form-control form-control add-text-value" id="newField_${newFieldId}" placeholder="Введите название для поля">
              </div>
              <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields">×</button></div>
            </div>`;



            } else

            if(radioName == "addTextarea") {
                createInputField = `<div class="form-group row border-top pt-3">

              <label for="newField_${newFieldId}" class="col-sm-3 col-form-label col-form-label">Текстовое поле</label>
<div class="col-sm-2">
                                            <input type="input" class="form-control form-control add-textarea-key" id="newFieldKey${newFieldId}" placeholder="Ключ">
                                        </div>
              <div class="col-sm-6">
                <input type="input" class="form-control form-control add-textarea" id="newField_${newFieldId}" placeholder="Введите название для текстового поля">
              </div>
              <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields">×</button></div>
            </div>`;
            }  else

            if(radioName == "addCheckboxes" || radioName == "addRadios") {
                let radioTitle = "радиокнопками";
                let cls = 'add-radio';
                let k = 'radio-key';
                let v = 'radio-val';
                let f_key = 'radio-field-key';
                let f_val = 'radio-field-val';
                let area = 'radio-area';
                if(radioName == "addCheckboxes") {
                    radioTitle = "чекбоксами";
                    cls = 'add-check';
                    k = 'check-key';
                    v = 'check-val';
                    f_key = 'check-field-key';
                    f_val = 'check-field-val';
                    area = 'check-area';
                }
                createInputField = `<div class="form-group row border-top pt-3 ${cls} f_trigger">

              <label for="newField_${newFieldId}" class="col-sm-3 col-form-label col-form-label">Поле с ${radioTitle}</label>
              <div class="col-sm-2">
                <input type="input" class="form-control form-control ${k}" id="newFieldKey${newFieldId}" placeholder="Ключ">
              </div>
              <div class="col-sm-6">
                <input type="input" class="form-control form-control ${v}" id="newField_${newFieldId}" placeholder="Введите название для поля с радиокнопками или чекбоксами">
              </div>
              <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields">×</button></div>
              <div class="col-6">
                  <div class="alert alert-info alert-dismissible">
                    Поле с ключами (только латинские буквы и цифры)
                  </div>
              </div>
              <div class="col-6">
                  <div class="alert alert-info alert-dismissible">
                    Поле с именами  (то, что будет написано в лейбле)
                  </div>
              </div>

              <div class="keysAndNames row">
                    <div class = '${area} row col-12 pr-0'>
                    <div class="col-6 mb-2">
                      <input type="text" class="form-control ${f_key}" placeholder="Ключ">
                    </div>
                    <div class="col-6 mb-2">
                      <input type="text" class="form-control ${f_val}" placeholder="Имя">
                    </div>
                    </div>
<div class = '${area} row col-12 pr-0'>
                    <div class="col-6 mb-2">
                      <input type="text" class="form-control ${f_key}" placeholder="Ключ">
                    </div>
                    <div class="col-6 mb-2">
                      <input type="text" class="form-control ${f_val}" placeholder="Имя">
                    </div>
</div>
                    <div class="col-12 mb-2">
                      <button class="btn btn-success float-right addSeccondFields">
                        <i class="fas fa-plus"></i>
                      </button>
                    </div>
              </div>
            </div>`;

            } else

            if(radioName == "addImg") {
                createInputField = `<div class="form-group row border-top pt-3 add-one-img">

          <label for="newField_${newFieldId}" class="col-sm-3 col-form-label col-form-label">Одно изображение</label>
          <div class="col-sm-2">
            <input type="input" class="form-control form-control one-img-key" id="newFieldKey${newFieldId}" placeholder="Ключ">
          </div>
          <div class="col-sm-6">
            <input type="input" class="form-control form-control one-img-val" id="newField_${newFieldId}" placeholder="Введите название для изображения">
          </div>
          <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields">×</button></div>


        <!--  <div class="col-12">
                  <div class="alert alert-info alert-dismissible">
                    Поля ниже преднозначены для обрезки изображений. Если не указывать, изображение будет загружено целиком.
                  </div>
              </div> -->
          <div class="row">
            <div class="col-6 mb-2">
                      <input type="hidden" value="1" class="form-control one-img-width" placeholder="Ширина в пикселях">
                    </div>
                    <div class="col-6 mb-2">
                      <input type="hidden" value="1" class="form-control one-img-height" placeholder="Высота в пикселях">
                    </div>
          </div>

          `;
            } else

            if(radioName == "addImgGroup") {
                createInputField = `<div class="form-group row border-top pt-3 add-many-img">

          <label for="newField_${newFieldId}" class="col-sm-3 col-form-label col-form-label">Группа изображений</label>
          <div class="col-sm-2">
            <input type="input" class="form-control form-control many-img-key" id="newFieldKey${newFieldId}" placeholder="Ключ">
          </div>
          <div class="col-sm-6">
            <input type="input" class="form-control form-control many-img-val" id="newField_${newFieldId}" placeholder="Введите название для изображения">
          </div>
          <div class="col-sm-1"><button type="button" class="btn bg-gradient-danger btn-sm removeFields">×</button></div>


        <!--  <div class="col-12">
                  <div class="alert alert-info alert-dismissible">
                    Поля ниже преднозначены для обрезки изображений. Если не указывать, изображение будет загружено целиком.
                  </div>
              </div> -->
          <div class="row">
            <div class="col-6 mb-2">
                      <input type="hidden" value="1" class="form-control many-img-width" placeholder="Ширина в пикселях">
                    </div>
                    <div class="col-6 mb-2">
                      <input type="hidden" value="1" class="form-control many-img-height" placeholder="Высота в пикселях">
                    </div>
          </div>

          `;
            }
            $('#mainStructure').append(createInputField)
            newFieldId++
        });

        //Удаление полей
        $(document).on('click', '.removeFields', function() {

            let removeElement = $(this).parent().parent();
            removeElement.remove();

        })

        //добавление строк в радиокнопки и чекбоксы
        $(document).on('click', '.addSeccondFields', function() {

            let prepearElement = $(this).parent();
            if($(this).closest('.f_trigger').hasClass('add-radio')) {
                var k_cls = 'radio-field-key';
                var v_cls = 'radio-field-val';
                var area = 'radio-area';
            } else {
                var k_cls = 'check-field-key';
                var v_cls = 'check-field-val';
                var area = 'check-area';
            }
            let addLines = `
        <div class="linesParent row col-12 pr-0 ${area}">
          <div class="col-6 mb-2">
              <input type="text" class="form-control ${k_cls}" placeholder="Ключ">
          </div>
          <div class="col-5 mb-2">
              <input type="text" class="form-control  ${v_cls}" placeholder="Имя">
          </div>
          <div class="col-1 pr-0">
            <button type="button" class="btn bg-gradient-danger removeLines float-right">×</button>

          </div>
        </div>
        `;
            prepearElement.before(addLines);

        })


        //удаление строк для радиокнопок и чекбоксов
        $(document).on('click', '.removeLines', function() {

            let removeElement = $(this).parent().parent();
            removeElement.remove();

        })

        $('.submit-object').click(function(){
            var name = $('#inputName').val();
            var key = $('#inputKey').val();
            var desc = $('#inputDescription').val();
            var o_id = $('#object_id').data('id');

            if($(this).hasClass('create')) {
                var create = true;
            } else {
                var create = false
            }

            if(name == '' || key == '' || desc == '') {
                alert('Заполните все поля');
                return false;
            }

            $.ajax({
                url: '/admin?r=site/submitobject',
                type: 'post',
                dateType: 'json',
                data: {name:name, k:key, desc:desc, create:create, id:o_id},
                success: function(){
              //      location.reload();
                }
            })
        })

        $(document).on('click', '.submit-object', function(){
            var object_id = $('.object_id').attr('data-id');

            var jsonObj = {
                object_id: object_id,
                text:{},
                textarea:{},
                radio: {
                    fields: {},
                },
                check: {
                    fields: {},
                },
                one_img: {},
                many_img: {},
            };
            var i = 0;
            $('.add-text').each(function(){
                var key = $(this).find('.add-text-key').val();
                var val = $(this).find('.add-text-value').val();

                ar = {
                    'key':key,
                    'value': val,
                }
                jsonObj.text[i] = ar;
                i++;
            });

            //  console.log(jsonObj);



            var i = 0;
            $('.add-textarea').each(function(){
                var key = $(this).closest('.form-group').find('.add-textarea-key').val();
                var val = $(this).val();

                tar = {
                    'key':key,
                    'value':val
                };
                jsonObj.textarea[i] = tar;
                i++;

            })

            i = 0;
            $('.add-radio').each(function() {
                var key = $(this).find('.radio-key').val();
                var val = $(this).find('.radio-val').val();
                var el = {
                    key: key,
                    val: val,
                };

                el.fields = {};



                //  alert(key + ' ' + val);
                var j = 0;
                $(this).find('.radio-area').each(function(){
                    var f_k = $(this).find('.radio-field-key').val();
                    var f_v = $(this).find('.radio-field-val').val();
                    var el2 = {
                        key: f_k,
                        val: f_v
                    };
                    el.fields[j] = el2;
                    //    jsonObj.radio.fields[j]['key'] = f_k;
                    //   jsonObj.radio.fields[j]['val'] = f_v;
                    j++;
                    //    alert(f_k + ' ' + f_v);
                })
                jsonObj.radio[i] = el;
                i++;
            })



            i = 0;
            $('.add-check').each(function() {
                var key = $(this).find('.check-key').val();
                var val = $(this).find('.check-val').val();
                var el = {
                    key: key,
                    val: val,
                };

                el.fields = {};
                // alert(key + ' ' + val);
                var j = 0;
                $(this).find('.check-area').each(function(){
                    var f_k = $(this).find('.check-field-key').val();
                    var f_v = $(this).find('.check-field-val').val();
                    var el2 = {
                        key: f_k,
                        val: f_v
                    };
                    el.fields[j] = el2;
                    j++;
                    // alert(f_k + ' ' + f_v);
                })
                jsonObj.check[i] = el;
                i++;
            })

            var i = 0;
            $('.add-one-img').each(function(){
                var one_img_key = $(this).find('.one-img-key').val();
                var one_img_val = $(this).find('.one-img-val').val();
                var one_img_h = $(this).find('.one-img-height').val();
                var one_img_w = $(this).find('.one-img-width').val();

                var el = {
                    'key': one_img_key,
                    'val': one_img_val,
                    'height': one_img_h,
                    'width': one_img_w,
                };
                jsonObj.one_img[i] = el;
                i++;

                //  alert(one_img_key + ' ' + one_img_val + ' ' + one_img_h + ' ' + one_img_w);
            })

            var i = 0;
            $('.add-many-img').each(function(){
                var many_img_key = $(this).find('.many-img-key').val();
                var many_img_val = $(this).find('.many-img-val').val();
                var many_img_h = $(this).find('.many-img-height').val();
                var many_img_w = $(this).find('.many-img-width').val();

                var el = {
                    'key': many_img_key,
                    'val': many_img_val,
                    'height': many_img_h,
                    'width': many_img_w,
                };

                jsonObj.many_img[i] = el;
                i++;

                // alert(many_img_key + ' ' + many_img_val + ' ' + many_img_h + ' ' + many_img_w);
            })

            var error = 0;
          /*  $('input[type=number]').each(function(){
                if($(this).val() == '') {
                    alert('Введите ширину и высоту изображения');
                    error = 1;
                    return false;
                }
            })
            if(error == 1) {
                return false;
            }*/

            $.ajax({
                url:'/admin?r=site/submitobjectfields',
                dataType: 'json',
                type: 'post',
                data: jsonObj,
                success: function(){
                    location.reload();
                }
            })


            // alert($('input[name=radioAdd]:checked').val());
        })

        $('.delete-old-field').click(function(){
            var type=$(this).data('type');
            var id = $(this).data('id');

            $.ajax({
                url:'/admin?r=site/delete-old-field',
                dataType: 'json',
                type: 'post',
                data: {type:type, id:id},
                success: function(){

                }
            })
        })

        $('.edit-old-field').focusout(function(){
            var id = $(this).data('id');
            var type = $(this).data('type');
            var field = $(this).data('field');
            var value = $(this).val();

            $.ajax({
                url:'/admin?r=site/edit-old-field',
                dataType: 'json',
                type: 'post',
                data: {type:type, id:id, field:field, value:value},
                success: function(){

                }
            })
        })

    });
</script>
