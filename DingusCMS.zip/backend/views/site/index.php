<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dignus CMS | Project Add</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">


  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/admin" class="brand-link">
      
      <span class="brand-text font-weight-light">Dignus CMS</span>
    </a>

      <div class="mt-3 sidebar">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
              <?php if($objects):?>
                  <?php foreach ($objects as $obj): ?>
                      <?php if($obj->existFields()):?>
                          <?php $url = 'edit-structure';?>
                          <?php $exist = true; ?>
                      <?php else: ?>
                          <?php $url = 'edit';?>
                          <?php $exist = false; ?>
                      <?php endif;?>
                      <li class="nav-item">
                          <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                              <i class="nav-icon fas fa-file"></i>
                              <p><?php echo $obj->name?></p>
                          </a>
                          <ul class="nav nav-treeview" style="display: none;">
                              <?php if($obj->is_assoc == 0):?>
                                  <li class="nav-item">
                                      <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                                          <i class="fas fa-pen nav-icon"></i>
                                          <p>Структура</p>
                                      </a>
                                  </li>
                              <?php else:?>

                                  <?php if($exist):?>
                                      <li class="nav-item">
                                          <a href="/admin?r=site/instance-list&id=<?php echo $obj->id?>" class="nav-link">
                                              <i class="fas fa-pen nav-icon"></i>
                                              <p>Экземпляры</p>
                                          </a>
                                      </li>
                                  <?php endif;?>
                              <?php endif;?>
                              <?php if($exist && $obj->is_assoc == 0):?>
                                  <li class="nav-item">
                                      <a href="/admin?r=site/content&id=<?php echo $obj->id?>" class="nav-link">
                                          <i class="fas fa-pen nav-icon"></i>
                                          <p>Наполнение</p>
                                      </a>
                                  </li>
                              <?php endif;?>

                              <li class="nav-item">
                                  <a target="_blank" href="/web/index.php?r=site/object&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Просмотреть вывод в массиве</p>
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a target="_blank" href="/web/index.php?r=site/object-json&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Просмотреть вывод в json</p>
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a onclick="return confirm('Удалить объект?')" href="/admin?r=site/delete-object&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-trash nav-icon"></i>
                                      <p style="color:red">Удалить объект</p>
                                  </a>
                              </li>

                          </ul>
                      </li>
                  <?php endforeach;?>
              <?php endif;?>
          </ul>

      </div>


  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Главная</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              
                                <a href="/admin?r=site/logout"><i class="fas fa-sign-out-alt"></i> Выйти</a>

            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <h5 class="m-0">Создать объект</h5>
            </div>
            <div class="card-body">
              <h6 class="card-title">Создать структуру одиночного объекта для вашего сайта</h6>

              <p class="card-text">Одиночный объект подходит для  блоков, в которых одна сущность. Например: блок сайта "О нас" или "Контакты". Для интеграции представляется в виде массива данных.</p>
              <a href="/admin?r=site/create" class="btn btn-primary">Создать одиночный объект</a>
            </div>
          </div>

        </div>
        <!-- /.col-md-6 -->
        <div class="col-lg-6">

          <div class="card card-primary card-outline">
            <div class="card-header">
              <h5 class="m-0">Создать экземпляр объекта</h5>
            </div>
            <div class="card-body">
              <h6 class="card-title">Создать структурный экземпляр объекта</h6>

              <p class="card-text">Подходит для блоков, в которых несколько схожих сущностей. Например: Слайдшоу, Отзывы, Карточки товаров. Для интеграции представляется в виде массива с вложенными массивами данных.</p>
              <a href="/admin?r=site/create-assoc" class="btn btn-primary">Создать экземпляр</a>
            </div>
          </div>
        </div>
        <!-- /.col-md-6 -->
        <!-- /.col-md-12 -->
        <div class="col-lg-12">

         <!-- <div class="card card-primary card-outline">
            <div class="card-header">
              <h5 class="m-0">Формат вывода массива</h5>
            </div>
            <div class="card-body">
              <p class="card-text">Вывод массива данных может быть либо в формате php переменной, либо в формате json массива. Ввыберите формат вывода массива удобный для вас. </p>
              <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h5><i class="icon fas fa-exclamation-triangle"></i> Внимание!</h5>
                Не меняйте это значение, если ваш сайт уже разработан.
              </div>
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" id="customRadio2" name="format" checked="">
                <label for="customRadio2" class="custom-control-label">Php - массив</label>
              </div>
              <div class="custom-control custom-radio mb-3">
                <input class="custom-control-input" type="radio" id="customRadio1" name="format" checked="">
                <label for="customRadio1" class="custom-control-label">Json - массив</label>
              </div>

              <a href="#" class="btn btn-primary">Сохранить</a>
            </div>
          </div>-->
        </div>
        <!-- /.col-md-12 -->
      </div>
      <!-- /.row -->
    </div>

  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/admin/dist/js/demo.js"></script>
</body>
</html>


