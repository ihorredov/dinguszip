<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dignus CMS | Project Add</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">


  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/admin" class="brand-link">
      <span class="brand-text font-weight-light">Dignus CMS</span>
    </a>

    <div class="mt-3 sidebar">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item menu-is-opening menu-open">
          <a href="#" class="nav-link active">
            <i class="nav-icon fas fa-copy"></i>
            <p>
              Слайдшоу
              <i class="fas fa-angle-left right"></i>

            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a href="#" class="nav-link active">
                <i class="fa-ellipsis-h fas nav-icon"></i>
                <p>Список элементов</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="fas fa-pen nav-icon"></i>
                <p>Изменить структуру</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="https://adminlte.io/docs/3.1/" class="nav-link">
            <i class="nav-icon fas fa-file"></i>
            <p>О нас</p>
          </a>
        </li>
      </ul>

    </div>

  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Добавить элемент</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Главная</a></li>
              <li class="breadcrumb-item"><a href="#">Слайдшоу</a></li>
              <li class="breadcrumb-item active">Изменить элемент</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">

        </div>
        <div class="card-body">
          <!---->
          <div class="attachment-block clearfix mb-3">
              <div class="form-group">
                <label for="inputName">Название</label>
                <input type="text" id="inputName" class="form-control" value="Слайд-1">
              </div>
          </div>
          <!---->
          <div class="attachment-block clearfix mb-3">
            <div class="form-group">
              <label for="inputName">Текст</label>
              <input type="text" id="inputName" class="form-control" value="lorem ipsum dolor">
            </div>
          </div>
          <!---->
          <div class="attachment-block clearfix mb-3">
            <div class="form-group">
              <label for="inputName">Текстовая область (подключить редактор текста)</label>
              <textarea id="inputDescription" class="form-control" rows="4"  value="lorem ipsum dolor"></textarea>
            </div>
          </div>
          <!---->
          <div class="attachment-block clearfix mb-3">

              <label for="inputName">Чекбоксы</label>
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input" type="checkbox" id="customCheckbox1" value="option1">
                  <label for="customCheckbox1" class="custom-control-label">Custom Checkbox</label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input class="custom-control-input" type="checkbox" id="customCheckbox2" checked="">
                  <label for="customCheckbox2" class="custom-control-label">Custom Checkbox checked</label>
                </div>

              </div>

          </div>
          <!---->
          <div class="attachment-block clearfix mb-3">

            <label for="inputName">Радиокнопки</label>
            <div class="form-group">
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" id="customRadio1" name="customRadio">
                <label for="customRadio1" class="custom-control-label">Custom Radio</label>
              </div>
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" id="customRadio2" name="customRadio" checked="">
                <label for="customRadio2" class="custom-control-label">Custom Radio checked</label>
              </div>

            </div>

          </div>

          <div class="attachment-block clearfix mb-3">

            <label for="inputName">Добавить одно изображение</label>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="customFile">
              <label class="custom-file-label" for="customFile">Добавить одно изображение</label>

            </div>
            <div class="card card-widget mt-3" style="width:30%">
              <div class="card-header">
                <div class="user-block">

                  <span class="username ml-0">Загруженное изображение</span>

                </div>
                <!-- /.user-block -->
                <div class="card-tools">

                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Удалить">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <img class="img-fluid pad" src="/admin/dist/img/photo2.png" alt="Photo">


              </div>
              <!-- /.card-body -->


            </div>

          </div>

          <div class="attachment-block clearfix mb-3">

            <label for="inputName">Добавить несколько изображений</label>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="customFile">
              <label class="custom-file-label" for="customFile">Добавьте изображения</label>

            </div>
            <div class="d-flex justify-content-between">
              <!--img-->
              <div class="card card-widget mt-3" style="width:30%">
                <div class="card-header">
                  <div class="user-block">
                    <span class="username ml-0">Загруженное изображение</span>
                  </div>
                  <!-- /.user-block -->
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Удалить">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <img class="img-fluid pad" src="/admin/dist/img/photo2.png" alt="Photo">
                </div>
                <!-- /.card-body -->
              </div>
              <!--/img-->

              <!--img-->
              <div class="card card-widget mt-3" style="width:30%">
                <div class="card-header">
                  <div class="user-block">
                    <span class="username ml-0">Загруженное изображение</span>
                  </div>
                  <!-- /.user-block -->
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Удалить">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <img class="img-fluid pad" src="/admin/dist/img/photo2.png" alt="Photo">
                </div>
                <!-- /.card-body -->
              </div>
              <!--/img-->

              <!--img-->
              <div class="card card-widget mt-3" style="width:30%">
                <div class="card-header">
                  <div class="user-block">
                    <span class="username ml-0">Загруженное изображение</span>
                  </div>
                  <!-- /.user-block -->
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Удалить">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <img class="img-fluid pad" src="/admin/dist/img/photo2.png" alt="Photo">
                </div>
                <!-- /.card-body -->
              </div>
              <!--/img-->
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>

  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/admin/dist/js/demo.js"></script>
</body>
</html>


