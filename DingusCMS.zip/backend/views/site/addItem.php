<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dignus CMS | Project Add</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">


  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/admin" class="brand-link">
      <span class="brand-text font-weight-light">Dignus CMS</span>
    </a>

      <div class="mt-3 sidebar">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
              <?php if($objects):?>
                  <?php foreach ($objects as $obj): ?>
                      <?php if($obj->existFields()):?>
                          <?php $url = 'edit-structure';?>
                          <?php $exist = true; ?>
                      <?php else: ?>
                          <?php $url = 'edit';?>
                          <?php $exist = false; ?>
                      <?php endif;?>
                      <li class="nav-item">
                          <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                              <i class="nav-icon fas fa-file"></i>
                              <p><?php echo $obj->name?></p>
                          </a>
                          <ul class="nav nav-treeview" style="display: none;">
                              <?php if($obj->is_assoc == 0):?>
                                  <li class="nav-item">
                                      <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                                          <i class="fas fa-pen nav-icon"></i>
                                          <p>Структура</p>
                                      </a>
                                  </li>
                              <?php else:?>

                                  <?php if($exist):?>
                                      <li class="nav-item">
                                          <a href="/admin?r=site/instance-list&id=<?php echo $obj->id?>" class="nav-link">
                                              <i class="fas fa-pen nav-icon"></i>
                                              <p>Экземпляры</p>
                                          </a>
                                      </li>
                                  <?php endif;?>
                              <?php endif;?>
                              <?php if($exist && $obj->is_assoc == 0):?>
                                  <li class="nav-item">
                                      <a href="/admin?r=site/content&id=<?php echo $obj->id?>" class="nav-link">
                                          <i class="fas fa-pen nav-icon"></i>
                                          <p>Наполнение</p>
                                      </a>
                                  </li>
                              <?php endif;?>

                              <li class="nav-item">
                                  <a target="_blank" href="/web/index.php?r=site/object&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Просмотреть вывод в массиве</p>
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a target="_blank" href="/web/index.php?r=site/object-json&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Просмотреть вывод в json</p>
                                  </a>
                              </li>
                              <li class="nav-item">
                                  <a onclick="return confirm('Удалить объект?')" href="/admin?r=site/delete-object&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-trash nav-icon"></i>
                                      <p style="color:red">Удалить объект</p>
                                  </a>
                              </li>
                          </ul>
                      </li>
                  <?php endforeach;?>
              <?php endif;?>
          </ul>

      </div>

  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Добавить элемент</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Главная</a></li>
              <li class="breadcrumb-item"><a href="#">Слайдшоу</a></li>
              <li class="breadcrumb-item active">Добавить элемент</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">

        </div>
        <div class="card-body">
            <p>
                <?php echo $object->description?>
            </p>
          <!---->
          <div class="attachment-block clearfix mb-3">
              <div class="form-group">
                <label for="inputName">Название</label>
                <input type="text" value="<?php echo $object->name?>" id="inputObjectName" data-id = '<?php echo $object->id?>' name="object_name" class="form-control">
              </div>
          </div>
          <!---->

      <!--      <div class="attachment-block clearfix mb-3">
                <div class="form-group">

                    <div class="card-header">
                        <h5 class="m-0">Формат вывода массива</h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Вывод массива данных может быть либо в формате php переменной, либо в формате json массива. Ввыберите формат вывода массива удобный для вас. </p>
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input format" type="radio" id="customRadio2" value="0" name="format" <?php echo $object->format==0?'checked':''?>>
                            <label for="customRadio2" class="custom-control-label">Php - массив</label>
                        </div>
                        <div class="custom-control custom-radio mb-3">
                            <input class="custom-control-input format" type="radio" id="customRadio1" value="1" name="format" <?php echo $object->format==1?'checked':''?>>
                            <label for="customRadio1" class="custom-control-label">Json - массив</label>
                        </div>

                        <div class="custom-control custom-radio mb-3">
                            <a target="_blank" href = '/web/index.php?r=site/object&id=<?php echo $object->id?>'>Просмотреть вывод</a>
                        </div>
                    </div>

                </div>
            </div>
 -->


            <?php if($textField):?>
                <?php foreach($textField as $text):?>
                      <div class="attachment-block clearfix mb-3">
                        <div class="form-group">
                          <label for="inputName"><?php echo $text->label?> (<?php echo $text->k?>)</label>
                          <input type="text" id="inputName" name="<?php echo $text->k?>" value="<?php echo $text->text?>" data-id="<?php echo $text->id?>" class="form-control text-field">
                        </div>
                      </div>
                <?php endforeach;?>
            <?php endif;?>
          <!---->

            <?php if($textArea):?>
            <?php foreach ($textArea as $area):?>
                  <div class="attachment-block clearfix mb-3">
                    <div class="form-group">
                      <label for="inputName"><?php echo $area->label?> (<?php echo $area->k?>)</label>
                      <textarea id="inputDescription" name="area_<?php echo $area->id?>" class="form-control textarea" data-id = "<?php echo $area->id?>" rows="4"><?php echo $area->text?></textarea>
                    </div>
                  </div>
            <?php endforeach?>
            <?php endif;?>
          <!---->

            <?php if($checkbox):?>
                <?php foreach ($checkbox as $check):?>
                  <div class="attachment-block clearfix mb-3">

                      <label for="inputName">Чекбоксы</label>
                      <?php if($check->boxes):?>
                          <?php foreach($check->boxes as $box):?>
                              <div class="form-group">
                                <div class="custom-control custom-checkbox checkboxes">
                                  <input data-id="<?php echo $box->id?>" class="custom-control-input" type="checkbox" <?php echo $box->enabled==1?'checked':0?> id="customCheckbox<?php echo $box->id?>" name="<?php echo $box->k?>" value="<?php echo $box->name?>">
                                  <label for="customCheckbox<?php echo $box->id?>" class="custom-control-label"><?php echo $box->name?></label>
                                </div>

                              </div>
                          <?php endforeach;?>
                      <?php endif;?>

                  </div>
                <?php endforeach;?>
            <?php endif;?>
          <!---->

            <?php if($radio):?>
                <?php foreach($radio as $r):?>
                  <div class="attachment-block clearfix mb-3">

                    <label for="inputName"><?php echo $r->name?></label>
                    <div class="form-group radiobuttons">
                        <?php if($r->buttons):?>
                            <?php foreach($r->buttons as $button):?>
                              <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" <?php echo $button->enabled==1?'checked':''?> data-id = '<?php echo $button->id?>' data-parent-id="<?php echo $r->id?>" id="customRadio<?php echo $button->id?>" value="<?php echo $button->name?>" name="><?php echo $r->k?>">
                                <label for="customRadio<?php echo $button->id?>" class="custom-control-label"><?php echo $button->name?></label>
                              </div>
                              <?php endforeach;?>
                        <?php endif;?>

                    </div>

                  </div>
                <?php endforeach;?>

            <?php endif;?>

        <?php if($oneImg):?>
                <?php foreach($oneImg as $img): ?>
              <div class="attachment-block clearfix mb-3">

                <label for="inputName">Добавить одно изображение</label>

                  <div class="custom-file" id="one-custom-file">
                      <?php $form = \yii\widgets\ActiveForm::begin(['action' => '/admin?r=site/one-file']) ?>
                      <?= $form->field($oneFileModel, 'file')->fileInput(['class' => 'custom-file-input', 'id' => 'customFile'.$img->id]) ?>
                      <?php echo $form->field($oneFileModel, 'id')->hiddenInput(['value'=> $img->id])->label(false);?>
                      <?php echo $form->field($oneFileModel, 'object_id')->hiddenInput(['value'=> $object->id])->label(false);?>
                      <label class="custom-file-label" for="customFile<?php echo $img->id?>">Добавить одно изображение</label>
                      <?php \yii\widgets\ActiveForm::end() ?>
                  </div>

                <div class="card card-widget mt-3" style="width:30%">
                  <div class="card-header">
                    <div class="user-block">

                      <span class="username ml-0">Загруженное изображение</span>

                    </div>
                    <!-- /.user-block -->
                    <div class="card-tools">

                      <button type="button" class="btn btn-tool delete-file" data-id = '<?php echo $img->img_id?>' data-type="one" data-card-widget="remove" title="Удалить">
                        <i class="fas fa-times"></i>
                      </button>
                    </div>
                    <!-- /.card-tools -->
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <img class="img-fluid pad" src="<?php echo $img->file?'/admin/uploads/'.$img->file:'/admin/dist/img/photo2.png'?>" alt="Photo">


                  </div>
                  <!-- /.card-body -->


                </div>

              </div>

            <?php endforeach;?>
        <?php endif;?>


            <?php if($manyImg):?>
            <?php foreach($manyImg as $many):?>
          <div class="attachment-block clearfix mb-3">

            <label for="inputName">Добавить несколько изображений</label>
            <div class="custom-file">
                <?php $form = \yii\widgets\ActiveForm::begin(['action' => '/admin?r=site/many-files']) ?>
                <?= $form->field($oneFileModel, 'file')->fileInput(['class' => 'custom-file-input-many', 'id' => 'manycustomFile'.$many->id]) ?>
                <?php echo $form->field($oneFileModel, 'id')->hiddenInput(['value'=> $many->id])->label(false);?>
                <?php echo $form->field($oneFileModel, 'object_id')->hiddenInput(['value'=> $object->id])->label(false);?>
              <label class="custom-file-label" for="manycustomFile<?php echo $many->id?>">Добавьте изображения</label>
                <?php \yii\widgets\ActiveForm::end() ?>

            </div>
            <div class="d-flex justify-content-between">
              <!--img-->

                <?php if($images = \common\models\ManyFilesInfo::find()->where(['field_id' => $many->id])->all()):?>
                    <?php foreach($images as $img):?>
                      <div class="card card-widget mt-3" style="width:30%">
                        <div class="card-header">
                          <div class="user-block">
                            <span class="username ml-0">Загруженное изображение</span>
                          </div>
                          <!-- /.user-block -->
                          <div class="card-tools">
                            <button type="button" class="btn btn-tool delete-file" data-id = '<?php echo $img->id?>' data-type = 'many' data-card-widget="remove" title="Удалить">
                              <i class="fas fa-times"></i>
                            </button>
                          </div>
                          <!-- /.card-tools -->
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                          <img class="img-fluid pad" src="<?php echo '/admin/uploads/'.$img->file?>" alt="Photo">
                        </div>
                        <!-- /.card-body -->
                      </div>
                      <!--/img-->
                    <?php endforeach; ?>
                    <?php else : ?>
                    <div class="card card-widget mt-3" style="width:30%">
                        <div class="card-header">
                            <div class="user-block">
                                <span class="username ml-0">Загруженное изображение</span>
                            </div>
                            <!-- /.user-block -->
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Удалить">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            <!-- /.card-tools -->
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <img class="img-fluid pad" src='/admin/dist/img/photo2.png' alt="Photo">
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!--/img-->
                <?php endif;?>



              <!--/img-->
            </div>
          </div>
            <?php endforeach;?>
            <?php endif;?>




        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>

  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/admin/dist/js/demo.js"></script>

<script>
    $('.checkboxes').find('input').change(function(){
        var id = $(this).attr('data-id');
        var val = $(this).prop('checked');

        $.ajax({
            url: '/admin?r=site/changebox',
            type: 'post',
            dateType: 'json',
            data: {id:id, val:val},
            success: function(){

            }
        })
    })

    $('.radiobuttons').find('input').change(function(){
        var parent = $(this).attr('data-parent-id');
        var id = $(this).attr('data-id');

        $.ajax({
            url: '/admin?r=site/changeradio',
            type: 'post',
            dateType: 'json',
            data: {id:id, parent:parent},
            success: function(){

            }
        })
    })

    $('#inputObjectName').focusout(function(){
        var id = $(this).attr('data-id');
        var val = $(this).val();

        $.ajax({
            url: '/admin?r=site/changeobjectname',
            type: 'post',
            dateType: 'json',
            data: {id:id, val:val},
            success: function(){

            }
        })
    })

    $('.text-field').focusout(function(){
        var id = $(this).attr('data-id');
        var val = $(this).val();

        $.ajax({
            url: '/admin?r=site/changename',
            type: 'post',
            dateType: 'json',
            data: {id:id, val:val},
            success: function(){

            }
        })
    })

    $('.textarea').focusout(function(){
        var id = $(this).attr('data-id');
        var val = $(this).val();

        $.ajax({
            url: '/admin?r=site/changearea',
            type: 'post',
            dateType: 'json',
            data: {id:id, val:val},
            success: function(){

            }
        })
    })

    $('.custom-file-input').change(function(){
        $(this).closest('form').submit();
    })

    $('.custom-file-input-many').change(function(){
        $(this).closest('form').submit();
    })

    $('.delete-file').click(function(e){
        e.preventDefault();
        var id = $(this).attr('data-id');
        var type = $(this).attr('data-type');

        $.ajax({
            url: '/admin?r=site/delete-file',
            type: 'post',
            dateType: 'json',
            data: {id:id, type:type},
            success: function(){

            }
        })

    })

    $('.format').change(function(){
        var id = $('#inputObjectName').attr('data-id');
        var val = $(this).val();

        $.ajax({
            url: '/admin?r=site/change-format',
            type: 'post',
            dateType: 'json',
            data: {id:id, val:val},
            success: function(){

            }
        })
    })
</script>


</body>
</html>


