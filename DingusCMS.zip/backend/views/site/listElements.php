<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dignus CMS | Project Add</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">


  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/admin" class="brand-link">
      <span class="brand-text font-weight-light">Dignus CMS</span>
    </a>

    <div class="mt-3 sidebar">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <?php if($objects):?>
              <?php foreach ($objects as $obj): ?>
                  <?php if($obj->existFields()):?>
                      <?php $url = 'edit-structure';?>
                      <?php $exist = true; ?>
                  <?php else: ?>
                      <?php $url = 'edit';?>
                      <?php $exist = false; ?>
                  <?php endif;?>
                  <li class="nav-item">
                      <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                          <i class="nav-icon fas fa-file"></i>
                          <p><?php echo $obj->name?></p>
                      </a>
                      <ul class="nav nav-treeview" style="display: none;">
                          <?php if($obj->is_assoc == 0):?>
                              <li class="nav-item">
                                  <a href="/admin?r=site/<?php echo $url?>&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Структура</p>
                                  </a>
                              </li>
                          <?php else:?>

                              <?php if($exist):?>
                                  <li class="nav-item">
                                      <a href="/admin?r=site/instance-list&id=<?php echo $obj->id?>" class="nav-link">
                                          <i class="fas fa-pen nav-icon"></i>
                                          <p>Экземпляры</p>
                                      </a>
                                  </li>
                              <?php endif;?>
                          <?php endif;?>
                          <?php if($exist && $obj->is_assoc == 0):?>
                              <li class="nav-item">
                                  <a href="/admin?r=site/content&id=<?php echo $obj->id?>" class="nav-link">
                                      <i class="fas fa-pen nav-icon"></i>
                                      <p>Наполнение</p>
                                  </a>
                              </li>
                          <?php endif;?>

                          <li class="nav-item">
                              <a target="_blank" href="/web/index.php?r=site/object&id=<?php echo $obj->id?>" class="nav-link">
                                  <i class="fas fa-pen nav-icon"></i>
                                  <p>Просмотреть вывод в массиве</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a target="_blank" href="/web/index.php?r=site/object-json&id=<?php echo $obj->id?>" class="nav-link">
                                  <i class="fas fa-pen nav-icon"></i>
                                  <p>Просмотреть вывод в json</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a onclick="return confirm('Удалить объект?')" href="/admin?r=site/delete-object&id=<?php echo $obj->id?>" class="nav-link">
                                  <i class="fas fa-trash nav-icon"></i>
                                  <p style="color:red">Удалить объект</p>
                              </a>
                          </li>
                      </ul>
                  </li>
              <?php endforeach;?>
          <?php endif;?>
      </ul>

    </div>

  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Экземпляры</h1>
              <a href="/admin?r=site/add-instance&id=<?php echo isset($_GET['id'])?$_GET['id']:''?>">Добавить объект</a>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Главная</a></li>
              <li class="breadcrumb-item active">Экземпляры</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"></h3>
            <p><?php echo $objectt->description?></p>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>

          </div>
        </div>
        <div class="card-body p-0">
          <table class="table table-striped projects">
              <thead>
                  <tr>
                      <th style="width: 1%">
                          #
                      </th>
                      <th style="width: 60%">
                          Наименование
                      </th>

                      <th style="width: 20%">
                      </th>
                  </tr>
              </thead>
              <tbody>
                  <?php if($instances):?>
                  <?php $i = 0;?>
                  <?php foreach ($instances as $one):?>
                      <?php $i++;?>
                  <tr>
                      <td>
                          <?php echo $i;?>
                      </td>
                      <td>
                          <a>
                              <?php echo $one->name?>
                          </a>


                      </td>


                      <td class="project-actions text-right">

                          <a class="btn btn-info btn-sm" href="/admin?r=site/instance-edit&id=<?php echo $one->id?>">
                              <i class="fas fa-pencil-alt">
                              </i>
                              Изменить
                          </a>
                          <a class="btn btn-danger btn-sm" onclick="return confirm('Удалить объект?')" href="/admin?r=site/delete-instance&id=<?php echo $one->id?>">
                              <i class="fas fa-trash">
                              </i>
                              Удалить
                          </a>
                      </td>
                  </tr>
                  <?php endforeach; ?>
              <?php endif;?>

              </tbody>
          </table>

        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    <!--  <nav aria-label="..." class="mt-4">
        <ul class="pagination">
          <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
          </li>
          <li class="page-item"><a class="page-link" href="#">1</a></li>
          <li class="page-item active" aria-current="page">
            <a class="page-link" href="#">2</a>
          </li>
          <li class="page-item"><a class="page-link" href="#">3</a></li>
          <li class="page-item">
            <a class="page-link" href="#">Next</a>
          </li>
        </ul>
      </nav> -->
    </section>

  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/admin/dist/js/demo.js"></script>
</body>
</html>


